﻿
<#
[CmdletBinding()]
Param(

    [Parameter(Mandatory=$True,Position=1)][string]$ServerName,
    [Parameter(Mandatory=$True,Position=2)][string]$WindowsServiceName,
    [Parameter(Mandatory=$True,Position=3)][string]$Action
)
#>

#try
#{
    [string]$ConfigFilePath = "F:\CGI\App\WindowsServiceManagement\WindowsServiceExecution\ServiceConfig.xml"

    #Reading Config details from XML Config file
    $ConfigFileocation = $ConfigFilePath #(Get-Location).Path + "\config.xml"
    If(!(Test-Path($ConfigFileocation)))
    {
        $_ErrorMessage= "Error Message: Invalid configuration file, please check configuration file availability!"             
        throw $_ErrorMessage
        WriteLogs -Message $_ErrorMessage
        Exit 
    }

    $SqlServerName = "CGIPEV"
    $SqlDatabaseName = "AppMonitoring"


    [XML]$XmlObject = Get-Content $ConfigFileocation       
    If($XmlObject.WindowsServiceDetails.HasChildNodes)
    {
        $EnvironmentCount = $XmlObject.WindowsServiceDetails.ChildNodes.Count;
        For($i=0;$i -le $EnvironmentCount-1; $i++)
	    {
            $strEnvironmnet = $XmlObject.WindowsServiceDetails.ChildNodes[$i].Attributes["Name"].Value
            if($XmlObject.WindowsServiceDetails.ChildNodes[$i].HasChildNodes)
            {
                $ServiceCount = $XmlObject.WindowsServiceDetails.ChildNodes[$i].ChildNodes.Count
                For($j=0;$j -le $ServiceCount-1; $j++)
	            {
                    $strServerName = $XmlObject.WindowsServiceDetails.ChildNodes[$i].ChildNodes[$j].Attributes["ServerName"].Value
                    $strServiceName = $XmlObject.WindowsServiceDetails.ChildNodes[$i].ChildNodes[$j].Attributes["ServiceName"].Value
                    $ErrorMessage =  StartStopWindowsService -ServerName $strServerName -WindowsServiceName $strServiceName -Action "Status"
                    $ServiceStatus = $ErrorMessage 
                    if($ServiceStatus -eq "Stopped" -or $ServiceStatus -eq "Running")
					{
                        $ErrorMessage = ""
                    }
                    else
					{
                    	$ServiceStatus = "Error"
                    }
                    $InsertQuery = "INSERT INTO [dbo].[JuniferWindowsServices]([Environment],[ServerName],[ServiceName],[Status],[ErrorMessage]) "
                    $InsertQuery += "VALUES('$strEnvironmnet','$strServerName','$strServiceName','$ServiceStatus','$ErrorMessage')" 
                    Write-Host $InsertQuery
                    Invoke-SQLcmd -ServerInstance $SqlServerName -query $InsertQuery -Database $SqlDatabaseName 
                }
            }

        }
        
    }



Function StartStopWindowsService([string]$ServerName,[string]$WindowsServiceName,[string]$Action)
{
    try
    {
        $winService = Get-Service -ComputerName $ServerName -Name $WindowsServiceName
        If($winService)
        {
            #Write-Host "Starting $WindowsServiceName Service from $ServerName"
            if($Action -eq "Start")
            {
                if($winService.Status -eq "Stopped")
                {
                    $winService.Start()
                }
                $winService.WaitForStatus("Running")
                If($winService.Status -eq "Running")
                {
                    #Write-Host "$WindowsServiceName Service from $ServerName has started!"
					return  $winService.Status
                }
                else
                {
					return  "Not able to start $WindowsServiceName"                        
                }
            }
            elseif($Action -eq "Stop")
            {
                if($winService.Status -eq "Running")
                {
                    $winService.Stop()
                }
                $winService.WaitForStatus("Stopped")
                If($winService.Status -eq "Stopped")
                {
                    #Write-Host "$WindowsServiceName Service from $ServerName has stopped!"
					return $winService.Status
				}
                else
                {
                    return  "Not able to stop $WindowsServiceName Junifer Windows service from $ServerName, please check/stop manually!"
                }
            }
            elseif($Action -eq "Status")
            {
                return $winService.Status
            }         
        }
        else
        {
            return "No Services available on Name:$WindowsServiceName in Server:$ServerName or you do not have access to this server!"
        }
    }
    catch
    {
        return $_.Exception.Message
    }
}

#Write-Output "Parameters value"
#Write-Output $ServerName
#$WindowsServiceName

