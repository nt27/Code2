﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Xml;
using System.Data;
using System.Data.Sql;
using System.Management.Automation;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Drawing;

namespace ServiceManagement_WebApp
{
    public partial class WebPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //LoadServiceDetailsInGrid();
                LoadEnvironmentDetails();
                LoadDatainGrid();
            }
        }

        private void LoadEnvironmentDetails()
        {
            string strServiceConfigFilePath = ConfigurationManager.AppSettings["ServiceConfigFilePath"].ToString();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(strServiceConfigFilePath);

            //drpEnvironment.Items.Add("--Select Environment--");
            drpEnvironment.Items.Add("All");

            foreach (XmlNode xmlNodeEnv in xmlDoc.DocumentElement.SelectNodes("/WindowsServiceDetails/Environment"))
            {
                string strEnvironment = xmlNodeEnv.Attributes["Name"].InnerText;
                drpEnvironment.Items.Add(strEnvironment);
            }
            drpEnvironment.SelectedIndex = 0;
        }
        private void GridStatusColor()
        {
            for (int i = 0; i <= grdPreProdDetails.Rows.Count - 1; i++)
            {
                string strCurrentStatus = grdPreProdDetails.Rows[i].Cells[5].Text.ToString();
                strCurrentStatus = Regex.Replace(strCurrentStatus, @"\t|\n|\r", "");
                if (strCurrentStatus == "Stopped")
                {
                    grdPreProdDetails.Rows[i].BackColor = Color.LightGreen;
                }
                else if (strCurrentStatus == "Error")
                {
                    grdPreProdDetails.Rows[i].BackColor = Color.Red;
                }
            }
        }
        private void LoadDatainGrid()
        {
            try
            {
                string strQuery = "Select ROW_NUMBER() Over (Order by CheckedDateTime desc) as SNO, Environment,ServerName, ServiceName,CheckedDateTime,Status,ErrorMessage From JuniferWindowsServices where 1=1 ";
                if (drpEnvironment.SelectedIndex != 0) strQuery += "and Environment='" + drpEnvironment.SelectedItem.ToString() + "'";
                if (chkToday.Checked)
                    strQuery += " and Cast(CheckedDateTime as Date) = Cast(getdate() as Date) ";
                else
                    strQuery += " and Cast(CheckedDateTime as Date) = Cast(getdate() - 3 as Date) ";
                string strConn = System.Configuration.ConfigurationManager.ConnectionStrings["SqlConnection"].ToString();
                SqlConnection SqlCon = new SqlConnection(strConn);
                SqlCon.Open();
                SqlCommand SqlCmd = new SqlCommand(strQuery, SqlCon);
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(SqlCmd);
                DataSet dsJuniferWindowsService = new DataSet();
                sqlDataAdapter.Fill(dsJuniferWindowsService);
                grdPreProdDetails.DataSource = dsJuniferWindowsService.Tables[0];
                grdPreProdDetails.DataBind();
                GridStatusColor();

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private string ExecutePowerShellScript(string strServerName, string strServiceName, string strAction)
        {
            try
            {
                string strScriptFilePath = ConfigurationManager.AppSettings["PowerShellFilePath"].ToString();
                using (PowerShell PowerShellInstance = PowerShell.Create())
                {
                    System.IO.StreamReader sr = new System.IO.StreamReader(strScriptFilePath);
                    string strFileContent = sr.ReadToEnd();
                    PowerShellInstance.AddScript(strFileContent);
                    PowerShellInstance.AddParameter("ServerName", strServerName);
                    PowerShellInstance.AddParameter("WindowsServiceName", strServiceName);
                    PowerShellInstance.AddParameter("Action", strAction);
                    Collection<PSObject> PSOutput = PowerShellInstance.Invoke();
                    string strOutput = "";
                    foreach (PSObject outputItem in PSOutput)
                    {
                        if (outputItem != null)
                        {
                            strOutput += outputItem.BaseObject.ToString() + "\n";
                        }
                    }
                    return strOutput;
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
                return null;
            }
        }
        private void LoadServiceDetailsInGrid()
        {
            try
            {
                //Data Table Columns
                DataTable dtServiceDetails = new DataTable();
                dtServiceDetails.Columns.Add("Environment", typeof(string));
                dtServiceDetails.Columns.Add("ServerName", typeof(string));
                dtServiceDetails.Columns.Add("ServiceName", typeof(string));
                dtServiceDetails.Columns.Add("CurrentStatus", typeof(string));

                string strServiceConfigFilePath = ConfigurationManager.AppSettings["ServiceConfigFilePath"].ToString();
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(strServiceConfigFilePath);

                foreach (XmlNode xmlNodeEnv in xmlDoc.DocumentElement.SelectNodes("/WindowsServiceDetails/Environment"))
                {
                    string strEnvironment = xmlNodeEnv.Attributes["Name"].InnerText;
                    XmlDocument xmlDocService = new XmlDocument();
                    for (int i = 0; i <= xmlNodeEnv.ChildNodes.Count - 1; i++)
                    {
                        string strServerName = xmlNodeEnv.ChildNodes[i].Attributes["ServerName"].InnerText;
                        string strServiceName = xmlNodeEnv.ChildNodes[i].Attributes["ServiceName"].InnerText;
                        dtServiceDetails.Rows.Add(strEnvironment, strServerName, strServiceName, "Status");
                    }
                }
                foreach (DataRow dtRow in dtServiceDetails.Rows)
                {
                    string strServerName = dtRow[1].ToString();
                    string strServiceName = dtRow[2].ToString();
                    string strAction = "Status";

                    dtRow[3] = ExecutePowerShellScript(strServerName, strServiceName, strAction);
                }

                //grdServiceDetails.DataSource = null;
                //grdServiceDetails.Columns.Clear();
                //grdServiceDetails.Rows.cle


                grdPreProdDetails.DataSource = dtServiceDetails;
                grdPreProdDetails.DataBind();

                //grdPrdDetails.DataSource = dtServiceDetails;
                // grdPrdDetails.DataBind();

                /* for (int i = 0; i <= grdServiceDetails.Rows.Count - 1; i++)
                 {
                     string strCurrentStatus = grdServiceDetails.Rows[i].Cells[3].Value.ToString();
                     strCurrentStatus = Regex.Replace(strCurrentStatus, @"\t|\n|\r", "");
                     if (strCurrentStatus == "Running")
                     {
                         grdServiceDetails.Rows[i].DefaultCellStyle.ForeColor = Color.Green;
                     }
                     else if (strCurrentStatus == "Stopped")
                     {
                         grdServiceDetails.Rows[i].DefaultCellStyle.ForeColor = Color.Red;
                     }
                 }*/

                /*if (grdServiceDetails.Columns.Count == 4)
               {
                  DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
                   grdServiceDetails.Columns.Add(btn);
                   btn.HeaderText = "Action";
                   btn.Text = "Start / Stop";
                   btn.Name = "btnAction";
                   btn.UseColumnTextForButtonValue = true;
            }*/

            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }

        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadDatainGrid();
        }
    }
}